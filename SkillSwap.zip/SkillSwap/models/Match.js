// Match.js
const mongoose = require('mongoose');

const matchSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' },
    matchId: { type: mongoose.Schema.Types.ObjectId, required: true, ref: 'User' },
    skill: { type: String, required: true },
    date: { type: Date, required: true },
});

const Match = mongoose.model('Match', matchSchema);

module.exports = Match;
