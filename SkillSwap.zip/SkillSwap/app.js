// app.js
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

app.use(bodyParser.json());

mongoose.connect('mongodb://localhost:27017/skillswap', { useNewUrlParser: true, useUnifiedTopology: true });

// Esquemas y rutas aquí

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
