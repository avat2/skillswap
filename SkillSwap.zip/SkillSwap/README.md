# SkillSwap

Bienvenidos a SkillSwap, una plataforma para intercambiar habilidades y conocimientos con personas de todo el mundo.

## Características

- **Intercambio de habilidades**: Encuentra y ofrece lecciones en una amplia variedad de campos.
- **Sistema de mensajería**: Comunícate con otros usuarios para organizar sesiones de intercambio.
- **Emparejamiento de habilidades**: Encuentra personas con las habilidades que deseas aprender y que desean aprender tus habilidades.
- **Comunidad de usuarios**: Conéctate y comparte experiencias con otros usuarios.
- **Foro de discusión**: Participa en debates y conversaciones sobre diversos temas.

## Instalación

1. Clona el repositorio:
   ```bash
   git clone <URL del repositorio>
   cd SkillSwap
